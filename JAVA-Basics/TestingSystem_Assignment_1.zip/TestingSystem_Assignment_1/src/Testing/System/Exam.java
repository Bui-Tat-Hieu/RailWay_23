package Testing.System;

import java.util.Date;

public class Exam {
	byte examId;
	String code;
	String title;
	CategoryQuestion categoryQuestion;
	String duration;
	Account account;
	Date createDate;
}
