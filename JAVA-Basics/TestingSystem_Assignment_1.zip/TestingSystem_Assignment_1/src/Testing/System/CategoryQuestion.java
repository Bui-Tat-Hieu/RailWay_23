package Testing.System;

public class CategoryQuestion {
	byte categoryId;
	String categoryName;

}
