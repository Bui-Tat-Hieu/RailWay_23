package Testing.System;

public class Department {
	byte departmentId;
	String departmentName;
	

}

	
