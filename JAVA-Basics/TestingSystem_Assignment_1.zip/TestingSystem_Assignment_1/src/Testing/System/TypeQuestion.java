package Testing.System;

public class TypeQuestion {
	byte typeId;
	TypeName typeName;

}
