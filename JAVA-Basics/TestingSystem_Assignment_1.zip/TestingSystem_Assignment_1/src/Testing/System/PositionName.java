package Testing.System;

public enum PositionName {
	DEV, TEST, SCRUMMASTER, PM;

}
