package Testing.System;

import java.util.Date;

public class GroupAccount {
	Group group;
	Account account;
	Date joinDate;

}
