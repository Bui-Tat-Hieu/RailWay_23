package Testing.System;

public class Answer {
	byte answerId;
	String content;
	Question question;
	boolean isCorrect;
}
