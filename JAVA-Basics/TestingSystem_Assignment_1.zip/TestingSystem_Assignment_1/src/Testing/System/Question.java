package Testing.System;

import java.util.Date;

public class Question {
	byte questionId;
	String content;
	CategoryQuestion categoryQuestion;
	TypeQuestion typeQuestion;
	Account account;
	Date createDate;
	
}
