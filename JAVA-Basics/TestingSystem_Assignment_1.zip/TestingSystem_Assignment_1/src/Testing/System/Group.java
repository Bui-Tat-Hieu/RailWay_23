package Testing.System;

import java.util.Date;

public class Group {
	byte groupId;
	String groupName;
	Account account;
	Date createDate;

}
