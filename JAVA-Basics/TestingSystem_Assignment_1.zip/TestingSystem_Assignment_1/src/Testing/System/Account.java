package Testing.System;

import java.util.Date;

public class Account {
	short accountId;
	String email;
	String userName;
	String fullName;
	Department department;
	Position position;
	Date createDate;

}
