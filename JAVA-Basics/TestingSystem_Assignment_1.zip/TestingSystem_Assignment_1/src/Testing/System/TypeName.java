package Testing.System;

public enum TypeName {
	ESSAY, MULTIPLE_CHOICE

}
