package Testing.System;

public class ExamQuestion {
	Exam exam;
	Question question;
	void goToSchool() {
		System.out.println("đi đến trường");
	}
}
