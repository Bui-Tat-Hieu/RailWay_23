package Testing.System;

public class Position {
	byte positionId;
	PositionName positionName;

}
